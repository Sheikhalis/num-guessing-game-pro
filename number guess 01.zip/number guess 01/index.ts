#! /usr/bin/env node
import inquirer from "inquirer";
import chalk from "chalk";
import chalkAnimation from "chalk-animation";
const generaterandomnumber = (min:number=1,max:number=10)=>{
return Number(Math.floor(Math.random()*(max-min+1))+min);
}
const Total_Round = 5;
let rounds = Total_Round;
let secretNumber = generaterandomnumber();
let wantTocontinue = true;
let record = {total:0 ,won :0,lost:0}
const asktoplayagain = async (win:boolean)=>{
  if(win){
    console.log("you won");
    
  }else{
    console.log(`you loss.secret num was${secretNumber} `);
  }
  console.log("lost");
  const again = await inquirer.prompt([{
    name:"again",
    type:"input",
    message:"Want to play again"
  }])
  if (again.again){
    rounds=Total_Round
    secretNumber=generaterandomnumber();
  }else{
    wantTocontinue=false;
    console.log(" Go in hell.....")
  }
}
  const welcomeMessage=()=>{
  console.clear();
  console.log("**************Record***************************")
  console.log(`Total Played : ${record.total},Won:${record.won},Lost:${record.lost}`)
  console.log("***********************************************")


  console.log("\nWelcome to seeret guessing name")
  console.log(`you will have ${Total_Round}rounds to guess the game`)
  }


const playRound = async()=>{
  const answer =await inquirer.prompt([{
    
      name:"guess",
      type:"input",
      message:"your guess",
      askAnswer:true,
      validate:(input)=>{
       if (isNaN(input)){
        return "Please enter a number"
       }
       if(Number(input)>10){
        return "Please enter a number less than 10"
       }
       return true;
      }
  
    }])

    rounds--;
    if(Number (answer.guess)===secretNumber){
      record.total++
      record.won++;
      await asktoplayagain(false);
    }
    else if(rounds>=1){
      console.log(`Wrong guess. you have ${rounds}left try again`);
      
    }
    else {
      record.total++
      record.lost++
      await asktoplayagain(false);
    }
}
    do{
      if (rounds ===Total_Round){
        welcomeMessage();
      }
      await playRound()
    }while (rounds>0 || wantTocontinue)





